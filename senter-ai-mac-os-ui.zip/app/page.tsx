import Component from "../liquid-glass-app"

export default function Page() {
  return <Component />
}
